import NextAuth from 'next-auth';
import GitHubProvider from 'next-auth/providers/github';
import Google from 'next-auth/providers/google';
import CredentialsProvider from 'next-auth/providers/credentials';
import { userLogin } from '@/services/user';

export default NextAuth({
    pages: {
        // if !session, redirect to /login
        signIn: '/auth/login'
    },
    secret: process.env.NEXTAUTH_SECRET,
    providers: [
        Google({
            clientId: process.env.GOOGLE_CLIENT_ID ?? "",
            clientSecret: process.env.GOOGLE_CLIENT_SECRET ?? ""
        }),
        GitHubProvider({
            clientId: process.env.GITHUB_ID ?? "",
            clientSecret: process.env.GITHUB_SECRET ?? ""
        }),
        CredentialsProvider({
            name: 'credentials',
            credentials: {
                email: { label: "Email", type: "email" },
                password: { label: "Password", type: "password" }
            },
            async authorize(credentials) {
                const payload = {
                    email: credentials?.email ?? "",
                    password: credentials?.password ?? "",
                };

                const response = await userLogin(payload);

                return response;
            }
        })
    ],
    // session: {
    //     strategy: 'jwt',
    // },
    callbacks: {
        async jwt({ user, token }: { user: any, token: any }) {
            if (user) {
                token.user = user
            }
            return token
        },
        async session({ session, token }: { session: any, token: any }) {
            session.user = token.user
            return session
        }
    }
})

// export const handler = NextAuth(authOptions);

// export { handler as GET, handler as POST }