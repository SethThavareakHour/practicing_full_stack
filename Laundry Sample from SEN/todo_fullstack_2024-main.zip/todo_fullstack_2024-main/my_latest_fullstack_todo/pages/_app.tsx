import "@/styles/globals.css";
import type { AppProps } from "next/app";
import { RecoilRoot } from "recoil";
import { SessionProvider } from "next-auth/react"
import { Toaster } from "react-hot-toast";

export default function App({ Component, pageProps:{ session, ...pageProps } }: AppProps) {
  return (
    <SessionProvider session={session }>
      <RecoilRoot>
        <Toaster position="top-right" />
        <Component {...pageProps} />;
      </RecoilRoot>
    </SessionProvider>
  )
}
