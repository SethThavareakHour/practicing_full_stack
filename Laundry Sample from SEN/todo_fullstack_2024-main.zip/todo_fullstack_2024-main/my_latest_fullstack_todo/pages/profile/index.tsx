"use client"
import React, { useState } from 'react'

import TodoList from '@/components/todo/TodoList'
import TodoAdd from '@/components/todo/TodoAdd'
import NavMenu from '@/components/NavMenu'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'

export default function Page() {
    const router = useRouter()
    const { data: session, status } = useSession({
        required: true,
        onUnauthenticated() {
            router.push('/auth/login')
        }
    })

    if (status === 'loading') {
        return 'Loading...'
    }

    return (
        <div className='flex flex-col justify-center items-center'>

            <NavMenu />

            <TodoAdd />
            <TodoList />

        </div>
    )
}
