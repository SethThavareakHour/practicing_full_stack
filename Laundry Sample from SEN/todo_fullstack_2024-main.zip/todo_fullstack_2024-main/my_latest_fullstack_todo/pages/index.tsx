import Image from "next/image";
import { Inter } from "next/font/google";
import { AllTodos } from "@/services/todo";
import { useEffect } from "react";
import { useRecoilState, useRecoilValue } from "recoil";
import { filteredTodoListState, todoState } from "@/recoil/atoms";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const inter = Inter({ subsets: ["latin"] });

export default function Home() {
  const [todos, setTodos] = useRecoilState(todoState);
  const todoList = useRecoilValue(filteredTodoListState)

  useEffect(() => {
    const fetchData = async () => {
      const response = await AllTodos();

      setTodos(response);
    };

    fetchData();

    // Fetch new todos at intervals (every 5 seconds in this example)
    const interval = setInterval(fetchData, 5000);

    // Clean up interval
    return () => {
      clearInterval(interval);
    };
  }, [])

  return (
    todoList.map((todo, index) => (
      <div className='flex flex-row justify-center items-center space-x-2 w-[50%] py-1' key={index}>
        <Input
          className=''
          type='text'
          value={todo.text}
          disabled
        />
      </div>
    ))
  );
}
