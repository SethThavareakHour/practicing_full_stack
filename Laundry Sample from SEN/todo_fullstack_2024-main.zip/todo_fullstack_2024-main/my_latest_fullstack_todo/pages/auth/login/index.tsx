"use client"
import React from 'react'
import { useRouter } from 'next/navigation';
import LoginForm from '@/components/auth/LoginForm';
import { useSession } from 'next-auth/react';

export default function Page() {
    const router = useRouter()
    const { data: session, status } = useSession()

    if (status === 'authenticated'){
        router.push('/profile')
    }

    return (
        <LoginForm />
    )
}
