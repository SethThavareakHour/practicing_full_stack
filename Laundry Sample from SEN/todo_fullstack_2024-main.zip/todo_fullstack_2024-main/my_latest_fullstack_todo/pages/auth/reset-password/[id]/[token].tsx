
import React from 'react'
import ResetPasswordChangeForm from '@/components/auth/ResetPasswordChangeForm'
import { GetServerSideProps } from 'next/types';

export default function Page({ id, token } : { id: string, token: string }) {  
  
  return (
      <ResetPasswordChangeForm id={id} token={token} />
  )
}

export const getServerSideProps : GetServerSideProps = async (context: any) => {
  const { id, token } = context.params;

  return {
    props: { id, token }
  }
}