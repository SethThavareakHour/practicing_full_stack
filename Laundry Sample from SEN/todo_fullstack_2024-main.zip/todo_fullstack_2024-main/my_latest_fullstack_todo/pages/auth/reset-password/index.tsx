// "use client"
import ResetPasswordForm from '@/components/auth/ResetPasswordForm'
import React from 'react'

export default function page() {
  return (
    <ResetPasswordForm />
  )
}
