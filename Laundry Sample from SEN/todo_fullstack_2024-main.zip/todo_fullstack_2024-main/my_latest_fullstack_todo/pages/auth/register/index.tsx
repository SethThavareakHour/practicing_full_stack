
import React, { useEffect } from 'react'
import { redirect, useRouter } from 'next/navigation';
import RegisterForm from '@/components/auth/RegisterForm';
import { useSession } from 'next-auth/react';

export default function Page() {
    const { data: session, status, update } = useSession();
    const router = useRouter();

    useEffect(() => {
        if (session) {
            router.push('/profile');
        }
    }, [session, router]);
    return (
        <RegisterForm />
    )
}
