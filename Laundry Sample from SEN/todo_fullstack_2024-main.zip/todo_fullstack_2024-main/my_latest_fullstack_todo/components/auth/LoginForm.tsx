"use client";
// react
import React, { useState } from 'react'
// shadcn
import {
    Form,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox"
// form validation
import { zodResolver } from "@hookform/resolvers/zod";
import { set, z } from "zod";
import { useForm } from "react-hook-form";
// resuable components
import CardWrapper from './CardWrapper';
// z schema
import { LoginSchema } from '@/schema';
import { LoaderIcon } from 'react-hot-toast';
// icon
import { GitHubLogoIcon, EyeOpenIcon, EyeClosedIcon } from '@radix-ui/react-icons';
import { FcGoogle } from 'react-icons/fc';
// next auth
import { signIn } from "next-auth/react";
import Link from 'next/link';
import { Label } from '../ui/label';
// api
import { userLogin } from '@/services/user';
// cookies
import { setCookie } from 'cookies-next';
// redirect
import { redirect, useRouter } from 'next/navigation';


export default function LoginForm() {
    const [isGithubLoading, setIsGithubLoading] = useState(false)
    const [isGoogleLoading, setIsGoogleLoading] = useState(false)
    const [isVisible, setIsVisible] = useState(false)

    const router = useRouter();

    const form = useForm({
        resolver: zodResolver(LoginSchema),
        defaultValues: {
            email: '',
            password: ''
        }
    });

    const onSubmit = async (data: z.infer<typeof LoginSchema>) => {
        
        const result = await userLogin(data);



        if (!result.error) {
            signIn('credentials', {
                email: data.email,
                password: data.password,
                redirectTo: '/profile'
            })
            setCookie('jwtToken', result.token)
            setCookie('user', JSON.stringify(result._id))
        }

    };

    return (
        <CardWrapper
            title="Sign In to your account"
            label="Enter your details to proceed further"
            backButtonHref="/auth/register"
            backButtonLabel="Don't have an account? Register here."
        >
            <Form {...form}>
                <form className='space-y-6'
                    onSubmit={form.handleSubmit(onSubmit)}
                >
                    <div className='space-y-2'>
                        <FormField
                            control={form.control}
                            name='email'
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Email</FormLabel>
                                    <FormControl>
                                        <Input {...field}
                                            type='email'
                                            placeholder='johndoe@gmail.com'
                                        />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name='password'
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Password</FormLabel>
                                    <FormControl>
                                        <div className='relative'>
                                            <Input {...field}
                                                type={isVisible ? 'text' : 'password'}
                                                placeholder='********'
                                                // required
                                            />
                                            <Button className='absolute top-0 right-0 hover:bg-transparent'
                                                variant="ghost"
                                                type='button'
                                                onClick={() => setIsVisible(!isVisible)}>
                                                {isVisible ?
                                                    <EyeOpenIcon className="h-4 w-4" /> :
                                                    <EyeClosedIcon className="h-4 w-4" />
                                                }
                                            </Button>
                                        </div>
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                    </div>
                    <div className='flex items-center'>
                        <Checkbox id='remember-me' />
                        <Label className='mx-2'
                            htmlFor='remember-me'
                        >
                            Remember me
                        </Label>
                    </div>
                    <Button className='w-full mt-4'
                        type='submit'
                        // variant='primary'
                        disabled={form.formState.isSubmitting}
                    >
                        {form.formState.isSubmitting ? <LoaderIcon /> : 'Login'}
                    </Button>
                </form>
            </Form>
            <div className='relative my-2'>
                <Link className='absolute top-0 right-0 text-xs text-slate-500 hover:underline'
                    href='/auth/reset-password'>
                    Forgot password?
                </Link>
            </div>

            <div className="relative mt-8 mb-2">
                <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-background px-2 text-muted-foreground">
                        Or continue with
                    </span>
                </div>
            </div>

            <Button className='w-full my-2'
                variant="outline"
                type="button"
                onClick={() => {
                    signIn('github', { redirectTo: '/profile' })
                    setIsGithubLoading(true)
                }}
                disabled={form.formState.isSubmitted}
            >
                {isGithubLoading ?
                    <LoaderIcon className='mr-2 h-4 w-4' /> :
                    <GitHubLogoIcon className='mr-2 h-4 w-4' />}{" "} Github
            </Button>

            <Button className='w-full my-2'
                variant='outline'
                type='button'
                onClick={() => {
                    signIn('google', { redirectTo: '/profile' })
                    setIsGoogleLoading(true)
                }}
                disabled={form.formState.isSubmitted}
            >
                {isGoogleLoading ?
                    <LoaderIcon className='mr-2 h-4 w-4' /> :
                    <FcGoogle className='mr-2 h-4 w-4' />
                }{" "}Google
            </Button>
        </CardWrapper>
    )
}
