"use client";
// react
import React, { useState } from 'react'
import Link from "next/link"
// shadcn
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from '@/components/ui/label';
// form validation
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useForm } from "react-hook-form";
// resuable components
import CardWrapper from './CardWrapper';
// z schema
import { ResetPasswordSchema } from '@/schema';
// icon
import { LoaderIcon } from 'react-hot-toast';
// api
import { userResetPassword } from '@/services/user';

export default function ResetPasswordForm() {
  const [isResetPasswordSent, setIsResetPasswordSent] = useState(false);

  const form = useForm({
    resolver: zodResolver(ResetPasswordSchema),
    defaultValues: {
      email: '',
    }
  });

  const onSubmit = (data: z.infer<typeof ResetPasswordSchema>) => {
    // setLoading(true);
    userResetPassword(data)
    setIsResetPasswordSent(true);
    console.log(data);
    // redirect('/register');
  };
  return (
    <>
      {!isResetPasswordSent ?
        <CardWrapper
          title="Reset your password"
          label="Please enter your email to reset your password"
          backButtonHref="/auth/login"
          backButtonLabel="Back to Login ?"
        >
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <FormField
                control={form.control}
                name='email'
                render={({ field }) => (
                  <FormItem>
                    {/* <FormLabel>Email</FormLabel> */}
                    <FormControl>
                      <Input {...field}
                        type='email'
                        placeholder='johndoe@gmail.com'
                      // required
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button className='w-full mt-4'
                type='submit'
                // variant='primary'
                disabled={form.formState.isSubmitting}
              >
                {form.formState.isSubmitting ? <LoaderIcon /> : 'Send email'}
              </Button>
            </form>
          </Form>
        </CardWrapper>
        :
        <CardWrapper
          title="Email sent successfully"
          label="Please check your inbox and reset your password"
          backButtonHref="/auth/login"
          backButtonLabel="Return to Login ?"
        >
          <Link className='flex items-center justify-center w-full py-2 text-white bg-blue-500 rounded-md hover:bg-blue-600'
            target='_blank'
            href='https://mail.google.com/mail/u/0/#inbox'>
            Open Gmail
          </Link>
          <Label className='flex text-center my-4'>
            If your inbox have not received the email, please click the button below to resent the email.
          </Label>
          <Button className='w-full'
            // TODO : add onClick event to resent email
            onClick={() => userResetPassword(form.getValues() as any)}
          >
            Resent email
          </Button>
        </CardWrapper>
      }
    </>
  )
}
