"use client";
// react
import React, { useState } from 'react'
// shadcn
import {
    Form,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from '@/components/ui/label';
// form validation
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useForm } from "react-hook-form";
// resuable components
import CardWrapper from './CardWrapper';
// z schema
import { ResetPasswordChangeSchema } from '@/schema';
// icon
import { LoaderIcon } from 'react-hot-toast';
import { userResetPasswordChange } from '@/services/user';
import { GetServerSideProps } from 'next/types';
import { useRouter } from 'next/navigation';

interface ResetPasswordChangeFormProps {
    id: string;
    token: string;
}

export default function ResetPasswordChangeForm({ id, token }: ResetPasswordChangeFormProps) {
    const router = useRouter();    

    const form = useForm({
        resolver: zodResolver(ResetPasswordChangeSchema),
        defaultValues: {
            newPassword: '',
            confirmPassword: ''
        }
    });

    // const response = await userResetPasswordChange({ id, token, password: data.newPassword })

    const onSubmit = async (data: z.infer<typeof ResetPasswordChangeSchema>) => {

        userResetPasswordChange({ id, token, password: data.newPassword })

        router.push('/auth/login')

        // userResetPasswordChange(response);
        // console.log(data);
    }

    return (
        <CardWrapper
            title="Reset your password"
            label="Please enter your new password"
            backButtonHref="/auth/login"
            backButtonLabel="Back to Login ?"
        >
            <Form {...form}>
                <form className='space-y-6'
                    onSubmit={form.handleSubmit(onSubmit)}
                >
                    <div className='space-y-4'>
                        <FormField
                            control={form.control}
                            name='newPassword'
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>New Password</FormLabel>
                                    <FormControl>
                                        <Input {...field}
                                            type='password'
                                            placeholder='Enter your password'
                                        />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name='confirmPassword'
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Confirm Password</FormLabel>
                                    <FormControl>
                                        <Input {...field}
                                            type='password'
                                            placeholder='Confirm your password'
                                        />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <Button className='w-full'
                            type='submit'
                        >
                            Reset Password
                        </Button>
                    </div>
                </form>
            </Form>
        </CardWrapper>
    )
}