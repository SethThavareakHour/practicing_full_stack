"use client";
import Link from "next/link";
import { signIn, signOut, useSession } from "next-auth/react";
import { Button } from "@/components/ui/button";
import { deleteCookie } from "cookies-next";

function AuthButton() {
    const { data: session } = useSession();

    if (session) {
        return (
            <>
                {session?.user?.name} <br />
                <Button onClick={() => {
                    // signOut()
                    signOut({ callbackUrl: '/auth/login', redirect: true})
                    deleteCookie('jwtToken')
                    // redirect('/login')
                }}>
                    Sign Out</Button>
            </>
        );
    }

    return (
        <>
            Not signed in <br />
            <Button onClick={() => signIn('google')}>Sign In with Google</Button>
            <Button onClick={() => signIn('github')}>Sign In with Github</Button>
            <Button onClick={() => signIn('credentials')}>Sign In with Credentials</Button>
        </>
    )
}

export default function NavMenu() {
    return (
        <div>
            <AuthButton />
        </div>
    )
}