import React, { useState, useEffect } from 'react'
// recoil
import { useRecoilState } from 'recoil';
import { todoState } from '@/recoil/atoms';
//type
import { TodoItem } from '@/types';
//component
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import toast from 'react-hot-toast';
import { getCookie } from 'cookies-next';
import { AllTodosByUser, todoCreate } from '@/services/todo';

export default function TodoAdd() {
    const [inputValue, setInputValue] = useState('');
    const [todos, setTodos] = useRecoilState(todoState);
    const cookiesJWT = getCookie('jwtToken');

    useEffect(() => {
        const fetchData = async () => {
            const cookiesID = getCookie('user');
            const cleanCookies = cookiesID?.substring(1, cookiesID.length - 1) || '';
            const response = await AllTodosByUser(cleanCookies);

            setTodos(response);
        };

        fetchData();
    }, [])


    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setInputValue(e.target.value);
    }

    const handleAdd = (e: React.MouseEvent<HTMLButtonElement> | React.KeyboardEvent<HTMLInputElement>) => {
        e.preventDefault();

        if (!inputValue) return;

        if (cookiesJWT) {
            todoCreate({ text: inputValue, isCompleted: false });
        }

        const newTodo: TodoItem = {
            text: inputValue,
            isCompleted: false
        }

        setTodos((prev) => [...prev, newTodo]);
        toast.success('Todo added successfully');
        setInputValue('');
    }

    const handleKeyUp = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            handleAdd(e);
        }
    }
    return (
        <div className='flex flex-row space-x-2 w-[50%] py-2'>

            <Input className=''
                name="Todo"
                placeholder='Write your todo...'
                autoComplete='off'
                value={inputValue}
                onChange={handleChange}
                onKeyUp={handleKeyUp}
            />
            <Button className='bg-emerald-500 text-white hover:bg-emerald-400'
                type='submit' onClick={handleAdd}>Add</Button>
        </div>
    )
}
