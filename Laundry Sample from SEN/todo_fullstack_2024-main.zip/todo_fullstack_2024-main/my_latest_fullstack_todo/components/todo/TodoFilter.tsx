import { filteredTodoListState, todoListFilterState } from '@/recoil/atoms'
import React from 'react'
import { useRecoilState, useRecoilValue } from 'recoil'

export default function TodoFilter() {
    // const todoList = useRecoilValue(filteredTodoListState)
    const [filter, setFilter] = useRecoilState(todoListFilterState)

    
    const updateFilter = ({target: {value}}: {target: {value: any}}) => {
        setFilter(value)
    }
  return (
    <>
      Filter:
      <select value={filter} onChange={updateFilter}>
        <option value="Show All">All</option>
        <option value="Show Completed">Completed</option>
        <option value="Show Uncompleted">Uncompleted</option>
      </select>
    </>
  )
}
