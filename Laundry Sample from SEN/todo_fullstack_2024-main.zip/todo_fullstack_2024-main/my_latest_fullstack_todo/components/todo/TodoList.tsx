"use client"
import React from 'react'

import { filteredTodoListState, todoListFilterState, todoState } from '@/recoil/atoms'
import { useRecoilState, useRecoilValue } from 'recoil'

import { Input } from '@/components/ui/input'
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from '../ui/button'
import { TodoItem } from '@/types'
import toast from 'react-hot-toast'
import TodoFilter from './TodoFilter'
import { TrashIcon } from 'lucide-react'
import { todoDelete, todoUpdate } from '@/services/todo'


export default function TodoList() {
    const todos = useRecoilValue(todoState)
    const [todo, setTodo] = useRecoilState(todoState)

    const todoList = useRecoilValue(filteredTodoListState)

    const handleTodoChange = (index: number, updatedTodo: TodoItem) => {
        setTodo((prevTodos) => {
            const newTodos = [...prevTodos];
            const oldIsCompleted = prevTodos[index].isCompleted; // Store the previous value of isCompleted
            newTodos[index] = updatedTodo;

            // Compare the new value of isCompleted with the old value
            if (updatedTodo.isCompleted !== oldIsCompleted) {
                updatedTodo.isCompleted
                    ? toast.success('Todo mark as completed')
                    : toast.error('Todo mark as uncompleted');
            }

            return newTodos;
        });

        todoUpdate(updatedTodo)
    }

    const handleTodoBlur = (index: number, updatedTodo: TodoItem) => {

        if (updatedTodo.text === '') {
            toast.error('Todo cannot be empty');
            handleTodoDelete(index)
            return;
        }

        setTodo((prevTodos) => {
            const newTodos = [...prevTodos];
            newTodos[index] = updatedTodo;
            return newTodos;
        });
        toast.success('Todo updated successfully');
    }

    const handleTodoDelete = (index: number) => {
        setTodo((prev) => prev.filter((_, i) => i !== index))
        toast.error('Todo deleted successfully');
    }


    return (
        <div className='flex flex-col justify-center items-center space-x-2 w-[100%]'>
            <h1>Todo list</h1>
            <TodoFilter />
            {todoList.map((todo, index) => (
                <div className='flex flex-row justify-center items-center space-x-2 w-[50%] py-1' key={index}>
                    <Input
                        className='h-6 w-6'
                        type='checkbox'
                        checked={todo.isCompleted}
                        onChange={(e) => handleTodoChange(index, { ...todo, isCompleted: e.target.checked })}
                    />
                    <Input
                        className=''
                        type='text'
                        value={todo.text}
                        onChange={(e) => handleTodoChange(index, { ...todo, text: e.target.value })}
                        onBlur={(e) =>
                            handleTodoBlur(index, { ...todo, text: e.target.value })}
                    // onClick={(e) => console.log(e.target.value)}
                    />
                    <Button
                        className='bg-red-500 hover:bg-red-500'
                        onClick={() => {
                            handleTodoDelete(index)
                            todoDelete(todo?._id as string)
                        }}
                    >
                        <TrashIcon className='h-6 w-6' />
                    </Button>
                </div>
            ))}
        </div>
    )
}
