import { atom, selector } from "recoil";
import { RecoilEnv } from "recoil";
import { TodoItem } from "@/types";

RecoilEnv.RECOIL_DUPLICATE_ATOM_KEY_CHECKING_ENABLED = false

export const todoState = atom<TodoItem[]>({
    key: 'todos',
    default: []
})

export const todoListFilterState = atom({
    key: 'todoListFilter',
    default: 'Show All'
})

export const filteredTodoListState = selector({
    key: 'FilteredTodoList',
    get: ({get}) => {
        const filter = get(todoListFilterState);
        const list = get(todoState);

        switch (filter) {
            case 'Show Completed':
                return list.filter((item) => item.isCompleted);
            case 'Show Uncompleted':
                return list.filter((item) => !item.isCompleted);
            default:
                return list;
        }
    }
})