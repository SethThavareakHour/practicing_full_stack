export type TodoItem = {
    _id?: string;
    text: string;
    isCompleted: boolean;
}