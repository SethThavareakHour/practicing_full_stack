import axios, { AxiosInstance, AxiosResponse } from 'axios';
import { getCookie } from 'cookies-next';

// create an axios instance function
export const createAxiosInstance = (baseURL: string): AxiosInstance => {
  const token = getCookie('jwtToken');

  const client = axios.create({
    baseURL,
    headers: {
      Authorization: 'Bearer ' + token
    }
  });

  // write an axios interceptors response handler
  client.interceptors.response.use(
    (response: AxiosResponse) => {
      return response;
    },
    (error: any) => {
      return Promise.reject(error);
    }
  );

  return client;
};
