import { ApiEndpoints } from "@/constants/index";
import { createAxiosInstance } from "@/utils/httpClient";
import { deleteCookie } from "cookies-next";
import { TodoItem } from "@/types";

const apiUrl: string = process.env.NEXT_PUBLIC_API_URL as string;

const api = createAxiosInstance(apiUrl);

export const todoCreate = async ({ text, isCompleted }: TodoItem): Promise<any> => {
    try {
        const response = await api.post(ApiEndpoints.Todo, { text, isCompleted });
        return response.data;
    } catch (error: any) {
        return {
            error: true,
            message: error.response.data.message
        }
    }
}

export const AllTodosByUser = async (id:string): Promise<any> => {
    try {
        const endpoint = ApiEndpoints.Todo + '/' + id;
        const response = await api.get(endpoint);
        return response.data;
    } catch (error: any) {
        return {
            error: true,
            message: error.response.data.message
        }
    }
}

export const todoDelete = async (id: string): Promise<any> => {
    try {
        const endpoint = ApiEndpoints.Todo + '/' + id;
        const response = await api.delete(endpoint);
        return response.data;
    } catch (error: any) {
        return {
            error: true,
            message: error.response.data.message
        }
    }
}

export const todoUpdate = async ({ _id, text, isCompleted }: TodoItem): Promise<any> => {
    try {
        const endpoint = ApiEndpoints.Todo + '/' + _id;
        const response = await api.put(endpoint, { text, isCompleted });
        return response.data;
    } catch (error: any) {
        return {
            error: true,
            message: error.response.data.message
        }
    }
}

export const AllTodos = async (): Promise<any> => {
    try {
        const response = await api.get(ApiEndpoints.Todo);
        return response.data;
    } catch (error: any) {
        return {
            error: true,
            message: error.response.data.message
        }
    }
}