import { ApiEndpoints } from "@/constants/index";
import { createAxiosInstance } from "@/utils/httpClient";
import { deleteCookie } from "cookies-next";

const apiUrl: string = process.env.NEXT_PUBLIC_API_URL as string;

const api = createAxiosInstance(apiUrl);

export const userRegister = async ({ name, email, password }: { name: string, email: string, password: string }): Promise<any> => {
    try {
        const response = await api.post(ApiEndpoints.UserRegister, { name, email, password });
        return response.data;
    } catch (error: any) {
        return {
            error: true,
            message: error.response.data.message
        }
    }
}

export const userLogin = async ({ email, password }: { email: string, password: string }): Promise<any> => {
    try {
        const response = await api.post(ApiEndpoints.UserLogin, { email, password });
        return response.data;
    } catch (error: any) {
        return {
            error: true,
            message: error.response.data.message
        }
    }
}

export const userLogout = async (): Promise<any> => {
    try {
        deleteCookie('jwtToken');
        return true;
    } catch (error: any) {
        return {
            error: true,
            message: error.response.data.message
        }
    }
}

export const userResetPassword = async ({ email }: { email: string }): Promise<any> => {
    try {
        const response = await api.post(ApiEndpoints.UserResetPassword, { email });
        return response.data;
    } catch (error: any) {
        return {
            error: true,
            message: error.response.data.message
        }
    }
}

export const userResetPasswordChange = async ({ id, token, password }: { id: string, token: string, password: string }): Promise<any> => {
    try {
        const endpoint = ApiEndpoints.UserResetPassword + '/' + id + '/' + token;

        const response = await api.post(endpoint, { password });
        
        return response.data;
    } catch (error: any) {
        return {
            error: true,
            message: error.response.data.message
        }
    }
}




