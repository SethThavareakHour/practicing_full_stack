const asyncHandler = require('express-async-handler');
// middleware
const { BadRequestError, UnauthorizedError } = require('../middleware/errorMiddleware');
// model
const Todo = require('../models/todoModel');

// @desc Create todo
// @route POST /api/todos/create
// @access Private
const createTodo = asyncHandler(async (req, res) => {
    const { text } = req.body;

    if (!text) {
        throw new BadRequestError('Please fill in all fields');
    }

    const todo = await Todo.create({
        user: req.user.id,
        text,
    });

    if (todo) {
        res.status(201).json({
            _id: todo._id,
            user: todo.user,
            text: todo.text,
            isCompleted: todo.isCompleted,
        });
    } else {
        throw new BadRequestError('Invalid todo data');
    }
});

// @desc Update todo
// @route PUT /api/todos/:id
// @access Private
const updateTodo = asyncHandler(async (req, res) => {
    const { id } = req.params;
    const { text, isCompleted } = req.body;

    if (!text) {
        throw new BadRequestError('Please fill todo');
    }

    if(!req.user){
        throw new UnauthorizedError('Unauthorized access');
    }

    const todo = await Todo.findById(id);

    if(todo.user.toString() !== req.user.id.toString()){
        throw new UnauthorizedError('Unauthorized access');
    }

    if (todo) {
        todo.text = text;
        todo.isCompleted = isCompleted;

        const updatedTodo = await todo.save();

        res.json(updatedTodo);
    } else {
        throw new BadRequestError('Invalid todo data');
    }
})

// @desc DELETE todo
// @route DELETE /api/todos/:id
// @access Private
const deleteTodo = asyncHandler(async (req, res) => {
    const { id } = req.params;

    if(!req.user){
        throw new UnauthorizedError('Unauthorized access');
    }

    const todo = await Todo.findByIdAndDelete(id);

    if(todo.user.toString() !== req.user.id.toString()){
        throw new UnauthorizedError('Unauthorized access');
    }

    if (todo) {
        res.json({ message: 'Todo removed' });
    } else {
        throw new BadRequestError('Invalid todo data');
    }
})

// @desc Get All todos by by user id
// @route GET /api/todos/:id
// @access Private
const getTodosByUserId = asyncHandler(async (req, res) => {
    const { id } = req.params;

    if (!id) {
        throw new BadRequestError('Invalid user id');
    }

    try {
        const todos = await Todo.find({ user: id });
        
        res.json(todos);
    } catch (error) {
        throw new BadRequestError('Invalid user id');
    }

})

// @desc GET all todos
// @route GET /api/todos/
// @access Public
const getAllTodos = asyncHandler(async (req, res) => {
    const todos = await Todo.find({});

    res.json(todos);
})

module.exports = {
    createTodo,
    updateTodo,
    deleteTodo,
    getTodosByUserId,
    getAllTodos,
}