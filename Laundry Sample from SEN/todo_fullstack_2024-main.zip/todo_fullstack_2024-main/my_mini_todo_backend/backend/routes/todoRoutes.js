const express = require('express');
const router = express.Router();
const {
    createTodo,
    updateTodo,
    deleteTodo,
    getTodosByUserId,
    getAllTodos,
} = require('../controllers/todoController.js');
const { protect } = require('../middleware/authMiddleware');

router.post('/', protect, createTodo);
router.put('/:id', protect, updateTodo);
router.delete('/:id', protect, deleteTodo);
router.get('/:id', protect, getTodosByUserId);
router.get('/', getAllTodos);

module.exports = router;