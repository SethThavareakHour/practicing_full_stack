'use strict';
const express = require('express');
const app = express();
const cors = require('cors');
const dotenv = require('dotenv').config();
const connectDB = require('./config/db');
const { errorHandler} = require('./middleware/errorMiddleware');
// const route
const userRoutes = require('./routes/userRoutes');
const todoRoutes = require('./routes/todoRoutes');

connectDB()
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// api route
app.use('/api/users', userRoutes);
app.use('/api/todos', todoRoutes);


app.use(errorHandler);

app.listen(process.env.PORT, () => {
    console.log(`Server started on port ${process.env.PORT}`)
})